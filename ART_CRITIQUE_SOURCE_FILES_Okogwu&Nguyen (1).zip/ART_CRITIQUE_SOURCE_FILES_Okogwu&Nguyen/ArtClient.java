import java.io.*;
import java.net.*;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


/*
Client class communicates with the server; Serves as a starting point for the new users.

Note to Professor: The print statements are uncommented to serve as a log
which helps keep track of server-client communication.

@author Beverley-Claire Okogwu & Linh Nguyen
@version due: April 22, 2021
*/
public class ArtClient
{
  private int port;
  private String host;
  private Socket clientSocket;

/**
Constructor
**/
public ArtClient(String host, int portNum)
{
  this.port = portNum;
  this.host = host;
}

/**
Client Program Begins
**/
public void startClient() throws Exception
{

  //connection socket
  clientSocket = new Socket(host, port);
  //Class to handle communication with the server
  ServerComm serverRequest = new ServerComm(clientSocket);
  // processes the chats from the server sent to all clients
  Thread thread = new Thread(serverRequest);
  // Start the thread
  thread.start();
}

/**
MAIN METHOD
**/
public static void main(String argv[]) throws Exception
{

  //ArtClient a = new ArtClient();

  //validate command line arguments
  if (argv.length <2 || argv.length >2)
  {
    System.out.println("2 ARGUMENTS, PLEASE!");
    return;
  }

  String host = argv[0];
  String port_string = argv[1];

  // parse & set the port number
  int port = Integer.parseInt(port_string);

  ArtClient artClient = new ArtClient(host, port);

  try
  {
    artClient.startClient();
  }catch(IOException e)
  {
    System.out.println("IOException occurs when the startClient function is called.");
  }



}
}


/**
This class sends and receives chat messages.
The class also handles updating the online portion of the users.
It is the main class where the user interacts with the chat window.
**/
final class ServerComm implements Runnable
{
  public Socket connect_sckt;
  public static DataOutputStream outToServer;
  public String artistName;
  public BufferedReader inFromServer;
  public BufferedReader inFromUser;
  public String activeNow;
  private String session_art;
  public static ArtGUI ag;
  public ArtServer asvr;



  /**
  Constructor
  **/
  public ServerComm(Socket clientSocket)
  {
    this.connect_sckt = clientSocket;
  }

  String art_msg;

  public void run()
  {
    try
    {
      outToServer = new DataOutputStream(connect_sckt.getOutputStream());
      inFromServer =new BufferedReader(new InputStreamReader(connect_sckt.getInputStream()));
      inFromUser = new BufferedReader(new InputStreamReader(System.in));

      /*
      The following lines are displays to make the entrance to the window user-friendly.
      */
      System.out.println("\n\nWelcome to the Art Critique Chat!\n PROUDLY presented by: \t Beverley and Linh!  ");
      System.out.println("============================================================================");

      System.out.println("\n Please Choose a color from the following:\n\t red, orange, yellow, green, blue, purple, pink, grey, white");
      String preferred_color = inFromUser.readLine();

      //receive art session from server
      session_art = inFromServer.readLine();
      System.out.println("\nYou will be viewing this art for the session: "+session_art);
      System.out.println("If you don't want this artwork, give it a go!\n Art is about exploring, so you don't have a chance to pick what you want to see :D\nHowever, feel free to rerun the Server [see ReadME if applicable] to get another random artwork :)");

      //prompt user for username
      System.out.println("\nPlease enter your artistic name: (No spaces, please!)");
      artistName = inFromUser.readLine();// read in the artists' user name

      outToServer.writeBytes(artistName+ "\n");

      //read active users from server if a new user
      activeNow= inFromServer.readLine();
      System.out.println("\nFrom here on, PLEASE use the graphics window to chat :)");

      //start the GUI
      ArtGUI ag = new ArtGUI(artistName,activeNow,session_art,preferred_color);
      ag.setVisible(true);

      String serverMsg;

      while (true)
      {

        //check to see if messages from the server DON'T contain the UPDATE keyword
        if((serverMsg = inFromServer.readLine())!=null && !(serverMsg.startsWith("UPDATE ")))
        {
          System.out.println(serverMsg);
          //put the message received on the GUI chat window
          ag.displayChatOnGUIFromServer(serverMsg);

        }
        else
        //This block ONLY updates the online portion of the GUI; it shows who is online
        {
          ag.updateUsers(serverMsg);
        }

      }
    }catch(IOException e)
    {
      System.out.println("This is an IOException in ServerComm class");
    }
    try
    {
      inFromUser.close();
      outToServer.close();
      connect_sckt.close();
    }catch(IOException e)
    {
      System.out.println("This is an IOException in closing the sockets");
    }

  }
}
