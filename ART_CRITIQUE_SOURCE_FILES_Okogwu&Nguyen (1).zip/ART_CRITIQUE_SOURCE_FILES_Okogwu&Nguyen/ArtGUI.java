import java.awt.*;
import javax.swing.*;
import javax.swing.border.Border;
import java.util.*;
import java.io.* ;
import java.net.* ;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;


/*
This class is the Graphic User Interface for the chat window

Note to Professor: The print statements are uncommented to serve as a log
which helps keep track of server-client communication.

@author Beverley-Claire Okogwu & Linh Nguyen
@version due: April 22, 2021
*/
public class ArtGUI extends JFrame
{
  //Border colors
  private Border greenline = BorderFactory.createLineBorder(Color.green);
  private Border pinkline = BorderFactory.createLineBorder(Color.pink);
  private Border orangeline = BorderFactory.createLineBorder(Color.orange);
  private Border blueline = BorderFactory.createLineBorder(Color.blue);
  //Theme colors
  private Color color_theme;
  private Color bckgrnd = new Color(254,216,177);
  //handles the messages inputed by the user
  public JTextField artisticTxt;
  //variables read from the client (used to construct the GUI)
  private String artist_username;
  private String online_artists;
  private String theme_color;
  //holds the currently online users
  public JTextArea online_users;
  //chat area
  public static JTextArea chat_display= new JTextArea();
  //art to view
  private String guiArt;
  //maps a color (inputed when the client runs) to its RGB code to set the theme of the chat.
  private HashMap<String,Color> colorRGBs = new HashMap<>();

  /**
  Constructor
  **/
  public ArtGUI(String username, String active_users, String session_art, String user_color)
  {
    //heading
    super("Welcome to Live Art Critique Chat, "+ username+ "!");

    this.artist_username = username;
    this.online_artists = active_users;
    this.guiArt = session_art;
    this.theme_color = user_color;
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.setSize(3200, 3200);
    this.setResizable(true);

    //HashMap settings (color --> RGB code)
    this.colorRGBs.put("red",new Color(252,88,88));
    this.colorRGBs.put("orange",new Color(254,216,177));
    this.colorRGBs.put("yellow",new Color(255,255,102));
    this.colorRGBs.put("green",new Color(144,238,144));
    this.colorRGBs.put("blue",new Color(173,216,230));
    this.colorRGBs.put("purple",new Color(197,139,231));
    this.colorRGBs.put("pink",new Color(250,134,196));
    this.colorRGBs.put("grey",new Color(211,211,211));
    this.colorRGBs.put("white",new Color(255,255,255));

    //construct the main panel
    JPanel mainPanel = new JPanel();
    mainPanel.setLayout(new BoxLayout(mainPanel,BoxLayout.Y_AXIS));
    this.add(mainPanel);
    mainPanel.add(getDisplays());
    mainPanel.add(artMessages());
    this.pack();

  }

  /**
  Gets the RGB codes for the color the user wants as his/her/their personal chat theme
  @return Color object representing RGB codes
  **/
  public Color getTheme(String theme_col)
  {
    if(colorRGBs.containsKey(theme_col))
    {
      return colorRGBs.get(theme_col);
    }
    else
    {
      return bckgrnd;
    }

  }

  /**
  Component specification
  **/
  private JPanel getDisplays()
  {

    JPanel panel = new JPanel();
    panel.setLayout(new BoxLayout(panel,BoxLayout.X_AXIS));
    panel.setBackground(getTheme(theme_color));

    panel.add(onlineAndChat(online_artists));
    panel.add(art());

    return panel;

  }

  /**
  holds the artwork for that session.
  **/
  private JPanel art()
  {

    JPanel art_panel = new JPanel();
    art_panel.setLayout(new BoxLayout(art_panel,BoxLayout.Y_AXIS));
    art_panel.setPreferredSize(new Dimension(300,300));
    art_panel.setBorder(greenline);
    art_panel.setBackground(getTheme(theme_color));

    JLabel art_label = new JLabel("What Do You Think of This Artwork?");
    art_panel.add(art_label);

    try
    {
      //user-defined path to the artworks folder:
      /*
      TO DO FOR NEW USERS: Copy+paste the path to the artworks folder HERE (the path variable)
                          - Remember to enclose the path with " " AND end with a ;
      */
      String path = "/Users/beverley-claireokogwu/Desktop/DICKINSON/SPRING2021/NETWORKS/FINAL_PROJECT/artworks";

      String ext = ".jpeg";
      String file_path = path+"/"+guiArt+ext;

      BufferedImage image = ImageIO.read(new File(file_path));
      JLabel label = new JLabel(new ImageIcon(image));
      //sets the artwork
      art_panel.add(label);
    }catch(IOException e)
    {
      System.out.println("IO Exception when getting the image file");
    }

    return art_panel;

  }



  /**
  Handles the online users and the chat window
  **/
  public JPanel onlineAndChat(String online_artists)
  {
    JPanel users_and_chat = new JPanel();
    users_and_chat.setLayout(new BoxLayout(users_and_chat, BoxLayout.Y_AXIS));

    JPanel online = new JPanel();
    online.setLayout(new BoxLayout(online, BoxLayout.Y_AXIS));

    JLabel online_label = new JLabel("...online...");
    //online_label.setFont(new Font("Comic Sans MS", Font.PLAIN, 10));
    online_users = new JTextArea(reformat(online_artists));
    //online_users.setPreferredSize(new Dimension(100,100));
    online_users.setEditable(false);

    //enable vertical and horizontal scrolling
    JScrollPane scroll0 = new JScrollPane(online_users);
    scroll0.setPreferredSize(new Dimension(400,150));

    online.add(online_label);
    online.add(online_users);

    online.setBorder(pinkline);

    chat_display.setBorder(orangeline);
    chat_display.setEditable(false);
    JScrollPane scroll = new JScrollPane(chat_display);
    scroll.setPreferredSize(new Dimension(400,150));

    users_and_chat.add(online);
    users_and_chat.add(scroll);

    return users_and_chat;
  }

  /**
  Update the online text area of the GUI whenever a user
  joins or leaves the chatroom.
  **/
  public void updateUsers(String fromServer)
  {
    online_users.setText(reformat(fromServer));
  }

  /**
  Takes a String separated by spaces and puts each item on a
  separate line.
  @return formatted String of online users
  **/
  public String reformat(String users_online)
  {
    String[] onlineNow = users_online.split(" ");
    String online_display = "";
    String end = "\n";

    for(int index=1; index<onlineNow.length;index++)
    {
      String person = onlineNow[index]+end;
      online_display+=person;
    }
    return online_display;

  }


  /**
  Adds the chat message received from a user to this user's chat window.
  **/
  public static void displayChatOnGUIFromServer(String message)
  {
    chat_display.append(message+"\n");
  }


  /**
  Handles where the user types his/her/their message
  **/
  private JPanel artMessages()
  {
    JPanel msg_panel = new JPanel();
    msg_panel.setLayout(new BoxLayout(msg_panel,BoxLayout.X_AXIS));
    msg_panel.setBackground(getTheme(theme_color));
    msg_panel.setSize(50, 30);
    //set the label to be the username of the artist.
    JLabel msg = new JLabel("["+artist_username+"]: ");
    msg_panel.add(msg);

    artisticTxt = new JTextField();
    artisticTxt.setPreferredSize(new Dimension(100,100));
    //add in a cursor
    artisticTxt.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
    msg_panel.add(artisticTxt);


    JButton sendButton = new JButton("Send Artistic Message");
    //set the listener for the button object.
    sendButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent event) {
        buttonAction(event);
      }
    });

    msg_panel.add(sendButton);
    msg_panel.setBorder(blueline);

    return msg_panel;

  }

  /**
  Takes care of what happens whenever the send button is clicked.
  **/
  public void buttonAction(java.awt.event.ActionEvent event)
  {
    //get the text from the text JTextField
    String artTxt = artisticTxt.getText();
    try
    {
      //format the text and send to server
      ServerComm.outToServer.writeBytes("~~["+artist_username+"]~~: "+artTxt+"\n");


    }catch(IOException e)
    {
      System.out.println(e);
    }
    //clear JTextField
    artisticTxt.setText("");

  }


}
