import java.io.*;
import java.net.*;
import java.util.*;

/*
The InstanceThread class handles each client's request.

Note to Professor: The print statements are uncommented to serve as a log
which helps keep track of server-client communication.

@author Beverley-Claire Okogwu & Linh Nguyen
@version due: April 22, 2021
*/
public class InstanceThread implements Runnable
{
  private Socket new_client_socket;
  private ArtServer artServer;
  private InputStream input;
  private BufferedReader br;
  private DataOutputStream os;
  private String artImage;

  /**
  Constructor
  **/
  public InstanceThread(Socket socket, String artWork, ArtServer aartServer)
  {
    this.new_client_socket = socket;
    this.artImage = artWork;
    this.artServer = aartServer;
  }

  public void run()
  {
    try
    {
      processRequest();
    }
    catch(IOException e)
    {
      System.out.print("There is an IO error in the processRequest() function!");

    }

  }

  /**
  Handles each client's communication
  **/
  private void processRequest() throws IOException
  {

    os = new DataOutputStream(new_client_socket.getOutputStream());
    //add this to the server's list of client's data output streams
    artServer.add_dos(os);
    br = new BufferedReader(new InputStreamReader(new_client_socket.getInputStream()));


    //send session art to the client
    os.writeBytes(artImage+"\n");

    //read username from the client
    String artist = br.readLine();
    System.out.println("Connected with artist: "+artist);

    //add the username to the array list of users from the ArtServer class
    artServer.art_users.add(artist);

    //send to ALL client's window
    artServer.updateOnlineList();

    //notification message
    String artistArrivalMessage = "New "+ getRandomVibe()+ " artist arrives:"+ artist;
    artServer.ShowAllUsers(artistArrivalMessage);//send to ALL clients
    System.out.println(artistArrivalMessage);

    String artMessage;

    //read the chats coming in from the clients
    while ((artMessage = br.readLine())!=null)
    {
      //send message read from one client to all the clients connected
      artServer.ShowAllUsers(artMessage);
      System.out.println(artMessage);

    }

    //once a client has quit the application, remove the client
    artServer.removeArtist(artist,this);
    new_client_socket.close();
    String artistLeavingMessage = artist + " left.";
    //notify other clients that an artist left the chat.
    artServer.ShowAllUsers(artistLeavingMessage);
    //update the online list accordingly
    artServer.updateOnlineList();

    System.out.println(artistLeavingMessage);

  }


  /**
  Generates a random "status" when a user enters the chatroom
  @return a String representing a funny adjective to describe the user
  **/
  public String getRandomVibe()
  {
    //list of random words and symbols
    String[] vibes = new String[]{"cool", "smart","happy", "elmo","goku","random","red","sweet","chicken","[•^w^•]","awesome", "boba"};
    Random rand = new Random();
    int vb = rand.nextInt(vibes.length);
    return vibes[vb];

  }

  /**
  Obtains the clients' DataOutputStreams
  @return a DataOutputStream object for the client
  **/
  public DataOutputStream getDataOutputStream()
  {
    System.out.println("In getDataOutputStream");
    if (os == null)
    {
      System.out.println("There is no outputstream here");
    }

    return os;
  }


}
