import java.io.*;
import java.net.*;
import java.util.*;

/*
Send Prof. Siddiqui files
*/

public class InstanceThread implements Runnable
{
  private Socket new_client_socket;
  private ArtServer artServer;
  private InputStream input;
  private BufferedReader br;
  private DataOutputStream os;
  private String artImage;

  public InstanceThread(Socket socket, String artWork, ArtServer aartServer)
  {
    this.new_client_socket = socket;
    this.artImage = artWork;
    this.artServer = aartServer;
  }

  public void run()
  {
    try
    {
      processRequest();
    }
    catch(IOException e)
    {
      System.out.print("There is an IO error in the processRequest() function!");

    }

  }

  private void processRequest() throws IOException
  {

    os = new DataOutputStream(new_client_socket.getOutputStream());
    //add this to the server's list of client's data output streams
    artServer.add_dos(os);
    br = new BufferedReader(new InputStreamReader(new_client_socket.getInputStream()));
    //w = new PrintWriter(os, true);

    //send session art to the client
    os.writeBytes(artImage+"\n");

    //read username from the client
    String artist = br.readLine();
    System.out.println("Connected with artist: "+artist);

    //add the username to the array list
    artServer.art_users.add(artist);

    //send to ALL client's window
    artServer.updateOnlineList();
    //os.writeBytes(artServer.getActiveUsers());

    //notification message
    String artistArrivalMessage = "New "+ getRandomVibe()+ " artist arrives:"+ artist;
    artServer.ShowAllUsers(artistArrivalMessage);
    System.out.println(artistArrivalMessage);

    String artMessage;
    String artistMessage;


    //read the chats
    while ((artMessage = br.readLine())!=null)
    {
      //artMessage = br.readLine();
      //System.out.println("We have read a line and are just about to send it out!");

      //send to clients currently online
      //ArtGUI.displayChatOnGUIFromServer(artMessage);
      artServer.ShowAllUsers(artMessage);

      System.out.println(artMessage);

    }

    //System.out.println("after loop");

    artServer.removeArtist(artist,this);
    new_client_socket.close();
    String artistLeavingMessage = artist + " left.";
    artServer.ShowAllUsers(artistLeavingMessage);
    //update the online list
    artServer.updateOnlineList();

    System.out.println(artistLeavingMessage);

  }



  /*
  public void displayArtists()
  {
    System.out.println("These artists are online: "+artServer.getArtistNames());
  }
  */



  public String getRandomVibe()
  {
    //list of random words = cool, happy, elmo,
    String[] vibes = new String[]{"cool", "happy", "elmo","goku","random","red","sweet","chicken","[•^w^•]","awesome", "boba"};
    Random rand = new Random();
    int vb = rand.nextInt(vibes.length);
    return vibes[vb];

  }

  public DataOutputStream getDataOutputStream()
  {
    System.out.println("In getDataOutputStream");
    if (os == null)
    {
      System.out.println("There is no outputstream here");
    }

    return os;
  }

  public void sendMessage(String message, DataOutputStream os)
  {
    //System.out.println("In send message");
    try
    {
      os.writeBytes(message);
    }catch(IOException e)
    {
      System.out.println("THERE IS AN IO EXCEPTION SOMEWHERE...");
    }

  }

}
