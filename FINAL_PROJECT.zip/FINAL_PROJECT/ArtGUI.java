import java.awt.*;
import javax.swing.*;
import javax.swing.border.Border;
import java.util.*;
import java.io.* ;
import java.net.* ;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;



public class ArtGUI extends JFrame
{
  private Border greenline = BorderFactory.createLineBorder(Color.green);

  private Border pinkline = BorderFactory.createLineBorder(Color.pink);
  private Border orangeline = BorderFactory.createLineBorder(Color.orange);
  private Border blueline = BorderFactory.createLineBorder(Color.blue);
  private Color color_theme;
  private Color bckgrnd = new Color(254,216,177);
  public JTextField artisticTxt;
  private String artist_username;
  private String online_artists;
  private String theme_color;
  public JTextArea online_users;
  public static JTextArea chat_display= new JTextArea();
  private String guiArt;
  private HashMap<String,Color> colorRGBs = new HashMap<>();

  public ArtGUI(String username, String active_users, String session_art, String user_color)
  {

    super("Welcome to Live Art Critique Chat, "+ username+ "!");
    this.artist_username = username;
    this.online_artists = active_users;
    this.guiArt = session_art;
    this.theme_color = user_color;
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.setSize(3200, 3200);
    this.setResizable(true);

    this.colorRGBs.put("red",new Color(252,88,88));
    this.colorRGBs.put("orange",new Color(254,216,177));
    this.colorRGBs.put("yellow",new Color(255,255,102));
    this.colorRGBs.put("green",new Color(144,238,144));
    this.colorRGBs.put("blue",new Color(173,216,230));
    this.colorRGBs.put("purple",new Color(197,139,231));
    this.colorRGBs.put("pink",new Color(250,134,196));
    this.colorRGBs.put("grey",new Color(211,211,211));
    this.colorRGBs.put("white",new Color(255,255,255));

    JPanel mainPanel = new JPanel();
    mainPanel.setLayout(new BoxLayout(mainPanel,BoxLayout.Y_AXIS));
    this.add(mainPanel);
    mainPanel.add(getDisplays());
    mainPanel.add(artMessages());
    this.pack();

  }


  public Color getTheme(String theme_col)
  {
    if(colorRGBs.containsKey(theme_col))
    {
      return colorRGBs.get(theme_col);
    }
    else
    {
      return bckgrnd;
    }

  }

  private JPanel getDisplays()
  {

    JPanel panel = new JPanel();
    panel.setLayout(new BoxLayout(panel,BoxLayout.X_AXIS));
    panel.setBackground(getTheme(theme_color));

    panel.add(onlineAndChat(online_artists));
    panel.add(art());

    return panel;

  }

  private JPanel art()
  {

    JPanel art_panel = new JPanel();
    art_panel.setLayout(new BoxLayout(art_panel,BoxLayout.Y_AXIS));
    art_panel.setPreferredSize(new Dimension(300,300));
    art_panel.setBorder(greenline);
    art_panel.setBackground(getTheme(theme_color));


    JLabel art_label = new JLabel("What Do You Think of This Artwork?");
    //art_label.setFont(new Font("Comic Sans MS", Font.PLAIN, 10));

    art_panel.add(art_label);

    try
    {
      String path = "/Users/beverley-claireokogwu/Desktop/DICKINSON/SPRING2021/NETWORKS/FINAL_PROJECT/artworks";
      String ext = ".jpeg";
      String file_path = path+"/"+guiArt+ext;

      BufferedImage image = ImageIO.read(new File(file_path));
      JLabel label = new JLabel(new ImageIcon(image));
      art_panel.add(label);
    }catch(IOException e)
    {
      System.out.println("IO Exception when getting the image file");
    }




    return art_panel;

  }



  public JPanel onlineAndChat(String online_artists)
  {
    JPanel users_and_chat = new JPanel();
    users_and_chat.setLayout(new BoxLayout(users_and_chat, BoxLayout.Y_AXIS));

    JPanel online = new JPanel();
    online.setLayout(new BoxLayout(online, BoxLayout.Y_AXIS));

    JLabel online_label = new JLabel("...online...");
    //online_label.setFont(new Font("Comic Sans MS", Font.PLAIN, 10));
    online_users = new JTextArea(reformat(online_artists));
    //online_users.setPreferredSize(new Dimension(100,100));
    online_users.setEditable(false);

    JScrollPane scroll0 = new JScrollPane(online_users);
    scroll0.setPreferredSize(new Dimension(400,150));

    online.add(online_label);
    online.add(online_users);

    online.setBorder(pinkline);

    chat_display.setBorder(orangeline);
    chat_display.setEditable(false);
    JScrollPane scroll = new JScrollPane(chat_display);
    scroll.setPreferredSize(new Dimension(400,150));

    users_and_chat.add(online);
    users_and_chat.add(scroll);

    return users_and_chat;
  }

  public void updateUsers(String fromServer)
  {
    online_users.setText(reformat(fromServer));
  }

  public String reformat(String users_online)
  {
    String[] onlineNow = users_online.split(" ");
    String online_display = "";
    String end = "\n";

    for(int index=1; index<onlineNow.length;index++)
    {
      String person = onlineNow[index]+end;
      online_display+=person;
    }
    return online_display;

  }


  public static void displayChatOnGUIFromServer(String message)
  {
    chat_display.append(message+"\n");
  }



  private JPanel artMessages()
  {
    JPanel msg_panel = new JPanel();
    msg_panel.setLayout(new BoxLayout(msg_panel,BoxLayout.X_AXIS));
    msg_panel.setBackground(getTheme(theme_color));
    msg_panel.setSize(50, 30);
    //set the label to be the username of the artist.
    JLabel msg = new JLabel("["+artist_username+"]: ");
    msg_panel.add(msg);

    artisticTxt = new JTextField();
    artisticTxt.setPreferredSize(new Dimension(100,100));
    artisticTxt.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
    msg_panel.add(artisticTxt);


    JButton sendButton = new JButton("Send Artistic Message");
    sendButton.addActionListener(new java.awt.event.ActionListener() {
      public void actionPerformed(java.awt.event.ActionEvent event) {
        buttonAction(event);
      }
    });

    msg_panel.add(sendButton);
    msg_panel.setBorder(blueline);

    return msg_panel;

  }

  public void buttonAction(java.awt.event.ActionEvent event)
  {
    //get the text from the text JTextField
    String artTxt = artisticTxt.getText();
    try
    {
      //format the text and send to server
      ServerComm.outToServer.writeBytes("~~["+artist_username+"]~~: "+artTxt+"\n");


    }catch(IOException e)
    {
      System.out.println(e);
    }
    //clear JTextField
    artisticTxt.setText("");

  }


}
