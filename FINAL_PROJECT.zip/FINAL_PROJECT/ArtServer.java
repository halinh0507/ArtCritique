import java.io.* ;
import java.net.* ;
import java.util.* ;
import javax.swing.*;
import javax.swing.JOptionPane;

/**
This is the server class for the live art critiqe chat system.
The server will basically wait and listen for connections for possible
clients, then begin a thread for each of the clients.
@author Beverley-Claire Okogwu & Linh Nguyen
@version due: April 22, 2021
**/
public class ArtServer
{
  //keeps track of the usernames
  public ArrayList<String> art_users= new ArrayList<>();
  //list of users' data output streams
  public ArrayList<DataOutputStream> art_users_dos= new ArrayList<>();
  private int portNumber;
  private static ArtGUI ag;
  //list of artworks
  public String[] art_images = {"greatWave","monalisa","japanese_modern_print","monroe","scream","starry_night"};
  private String displayed_art;

  public ArtServer(int port)
  {
    this.portNumber = port;
  }

  public void startChat()
  {

    try
    {
      // Establish the listening socket.
      ServerSocket listen_socket = new ServerSocket(portNumber);
      System.out.println("LISTENING SOCKET ESTABLISHED, WAITING FOR CONNECTION REQUESTS... ");//status message
      //obtain the artwork for that session
      displayed_art = getRandomArt();

      // Process incoming requests in an infinite loop.
      while (true)
      {
        // Listen for a TCP connection request.
        Socket connection_socket = listen_socket.accept();
        //InstanceThread processes the request
        InstanceThread artCriticUserRequest = new InstanceThread(connection_socket, displayed_art, this);
        // Create a new thread to process the request.
        Thread thread = new Thread(artCriticUserRequest);
        // Start the thread.
        thread.start();

      }
    }catch(IOException e)
    {
      System.out.println("There is an IO Exception somewhere.");
    }

  }

  public String getRandomArt()
  {

    Random rand = new Random();
    int art_index = rand.nextInt(art_images.length);

    return art_images[art_index];
  }

  synchronized public void add_dos(DataOutputStream os)
  {
    art_users_dos.add(os);
  }


  synchronized public void ShowAllUsers(String message)
  {


    for (DataOutputStream d: art_users_dos)
    {

      try
      {
        d.writeBytes(message+"\n");
      }catch(IOException e)
      {
        System.out.println("There is an IO Exception somewhere. This is in the ShowAllUsers function");
      }

    }

  }


  synchronized public String getActiveUsers()
  {
    String userStr = "";
    for (String artist : art_users)
    {
      String format_artist= artist + " ";
      userStr+=format_artist;
    }
    return userStr+"\n";
  }

  /*
  sends the list of current users to all clients
  */
  synchronized public void updateOnlineList()
  {

    System.out.println("\n\tActive users: "+getActiveUsers());

    for(DataOutputStream d: art_users_dos)
    {
      try
      {
        d.writeBytes("UPDATE "+getActiveUsers());
      }catch(IOException e)
      {
        System.out.println("There is an IO Exception somewhere. This is in the updateOnlineList function");
      }

    }

  }




  public void removeArtist(String artist, InstanceThread it)
  {
    Boolean left = art_users.remove(artist);

    if (left)
    {
      //remove that user's dos
      art_users_dos.remove(it.getDataOutputStream());
    }

  }


  public static void main(String argv[])
  {

    //read the command line arguments
    if (argv.length <2 || argv.length >2)
    {
      System.out.println("2 ARGUMENTS, PLEASE!");
      return;
    }

    String host = argv[0];
    String port_string = argv[1];

    // parse & set the port number
    int port = Integer.parseInt(port_string);

    //create instance of the art server and pass in the port number
    ArtServer art = new ArtServer(port);
    //start the chat system
    art.startChat();


  }
}
